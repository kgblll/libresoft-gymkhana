# -*- coding: UTF-8 -*-

from apps.explohyperfiction.rest import user
from django.http import HttpResponse, HttpResponseRedirect
from django.template.loader import get_template
from django.template import Context, RequestContext
from django.shortcuts import render_to_response

from apps.explohyperfiction.core import api
from apps.explohyperfiction.core import utils
from apps.explohyperfiction.models import *

from social.core import api as api_lgs
from social.rest.forms import LoginForm
from social.core.models import *

def home(request):
    data={}
    api.group.create_free_group()
    if request.user.is_authenticated():
        data["login"]=True
        data["name"]=request.user.username
        person=Person.objects.get(id=request.session["_auth_user_id"])
        if Player.objects.filter(person=person).exists():
            data["member"]=True
            player=Player.objects.get(person=person)
            data["player"]=player
            data["number_of_notices"]=len(SystemMessage.objects.filter(to=player))
    if(len(Player.objects.filter(is_superuser=True))<1):
        data["superuser"]=True
    if request.method!="GET":
        data["message"]="Forbidden operation"
        return render_to_response("explohyperfiction_error.html", data)
    data["number_of_petitions"]=len(Petition.objects.all())
    template=get_template("explohyperfiction_base.html")
    return HttpResponse(template.render(RequestContext(request,data)))