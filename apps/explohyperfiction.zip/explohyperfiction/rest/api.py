# -*- coding: UTF-8 -*-


from django.http import HttpResponse, HttpResponseRedirect
from django.template.loader import get_template
from django.template import Context, RequestContext
from django.shortcuts import render_to_response
from datetime import datetime

from django.contrib.auth import authenticate, login, logout

from social.core import api as api_lgs
from social.rest.forms import LoginForm
from social.core.models import *
from apps.explohyperfiction.core import utils
from apps.explohyperfiction.models import *
from apps.explohyperfiction.core import api

def api_json_login(request):
    if request.method=="POST":
        loginform = LoginForm(request.POST)
        if loginform.login(request):
            return HttpResponseRedirect("/explohyperfiction/home/")
        else:
            return HttpResponseRedirect("/explohyperfiction/user/login/")
    if request.method=="GET":
        data={}
        template=get_template("explohyperfiction_user_login.html")
        return HttpResponse(template.render(RequestContext(request,data)))
    

def api_json_groups_view(request):
    person=Person.objects.get(id=request.session["_auth_user_id"])
    player=Player.objects.get(person=person)
    data={}
    data["groups"]=player.groups.all()
    template=get_template("api_json_groups.json")
    return HttpResponse(template.render(Context(data)))

def api_json_groups_all(request):
    person=Person.objects.get(id=request.session["_auth_user_id"])
    player=Player.objects.get(person=person)
    data={}
    data["groups"]=Group.objects.all()
    template=get_template("api_json_groups.json")
    return HttpResponse(template.render(Context(data)))
 
def api_json_groups_profile(request, id_group):
    person=Person.objects.get(id=request.session["_auth_user_id"])
    player=Player.objects.get(person=person)
    data={}
    group= Group.objects.get(id=int(id_group))
    data["group"]=Group.objects.get(id=int(id_group))
    data["petition"]=PetitionGroup.objects.filter(group=group, player=player).exists()
    if group in player.groups.all():
        data["member"]=True
    template=get_template("api_json_groups_profile.json")
    return HttpResponse(template.render(Context(data)))

def api_json_groups_join(request,id_group):
    person=Person.objects.get(id=request.session["_auth_user_id"])
    player=Player.objects.get(person=person)
    data={}
    group= Group.objects.get(id=int(id_group))
    player.groups.add(group)
    player.save()
    return HttpResponse()

def api_json_groups_quit(request,id_group):
    person=Person.objects.get(id=request.session["_auth_user_id"])
    player=Player.objects.get(person=person)
    data={}
    group= Group.objects.get(id=int(id_group))
    player.groups.remove(group)
    player.save()
    return HttpResponse()

def api_json_groups_petition_add(request,id_group):
    person=Person.objects.get(id=request.session["_auth_user_id"])
    player=Player.objects.get(person=person)
    data={}
    group= Group.objects.get(id=int(id_group))
    api.petition_group.create(player,group)
    return HttpResponse()
    
def api_json_groups_petition_quit(request,id_group):
    person=Person.objects.get(id=request.session["_auth_user_id"])
    player=Player.objects.get(person=person)
    data={}
    group= Group.objects.get(id=int(id_group))
    petition=PetitionGroup.objects.get(group=group, player=player)
    petition.delete()
    return HttpResponse()

def api_json_events_all(request):
    person=Person.objects.get(id=request.session["_auth_user_id"])
    player=Player.objects.get(person=person)
    data={}
    data["events"]=Event.objects.filter(group__in=player.groups.all(),active=True)
    template=get_template("api_json_events.json")
    return HttpResponse(template.render(Context(data)))

def api_json_events_group(request,id_group):
    person=Person.objects.get(id=request.session["_auth_user_id"])
    player=Player.objects.get(person=person)
    data={}
    group= Group.objects.get(id=int(id_group))
    data["events"]=Event.objects.filter(group=group,active=True)
    template=get_template("api_json_events.json")
    return HttpResponse(template.render(Context(data)))
    
def api_json_events_profile(request,id_event):
    person=Person.objects.get(id=request.session["_auth_user_id"])
    player=Player.objects.get(person=person)
    data={}
    data["event"]=Event.objects.get(id=int(id_event))
    template=get_template("api_json_event_profile.json")
    return HttpResponse(template.render(Context(data)))
  
def api_json_challenge_start(request,id_event):
    person=Person.objects.get(id=request.session["_auth_user_id"])
    player=Player.objects.get(person=person)
    data={}
    event=Event.objects.get(id=int(id_event))
    challenge=api.challenge.create(event,player,True)
    question=Question.objects.filter(event=event,level=1)[0]
    data["question"]=question
    data["challenge"]=challenge
    template=get_template("api_json_questions.json")
    return HttpResponse(template.render(Context(data)))

def api_json_question_answers(request,id_question):
    question=Question.objects.get(id=int(id_question))
    data={}
    data["answers"]=Answer.objects.filter(question=question)
    template=get_template("api_json_answers.json")
    return HttpResponse(template.render(Context(data)))

def api_json_challenge_question(request,id_challenge,id_question,id_answer):
    question=Question.objects.get(id=int(id_question))
    data={}
    answer=Answer.objects.get(id=int(id_answer))
    challenge=Challenge.objects.get(id=int(id_challenge))
    api.responses.create(challenge,question,answer)
    data["question"]=Question.objects.get(id=int(answer.next))
    data["challenge"]=challenge
    template=get_template("api_json_questions.json")
    return HttpResponse(template.render(Context(data)))

def api_json_challenge_finish(request,id_challenge,id_question,id_answer):
    question=Question.objects.get(id=int(id_question))
    data={}
    answer=Answer.objects.get(id=int(id_answer))
    challenge=Challenge.objects.get(id=int(id_challenge))
    api.responses.create(challenge,question,answer)
    challenge.date_finish=datetime.now()
    challenge.finish=True
    challenge.save()
    data["challenge"]=challenge
    template=get_template("api_json_challenge.json")
    return HttpResponse(template.render(Context(data)))

def api_json_summary(request,id_challenge):
    data={}
    challenge=Challenge.objects.get(id=int(id_challenge))
    data["summaries"]=Responses.objects.filter(challenge=challenge)
    template=get_template("api_json_summary.json")
    return HttpResponse(template.render(Context(data)))