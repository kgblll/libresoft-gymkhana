# -*- coding: UTF-8 -*-

from apps.explohyperfiction.models import *
from apps.explohyperfiction.core import api

def get_max_level(event):
    questions=Question.objects.filter(event=event)
    max=0
    for q in questions:
        if max < q.level:
            max=q.level
    return max+1

def get_width(event):
    questions=Question.objects.filter(event=event)
    answers=Answer.objects.filter(question__event=event)
    max_questions=0
    max_level=get_max_level(event)
    for i in range(max_level):
        if len(Question.objects.filter(event=event, level=i))>max_questions:
            max_questions=len(Question.objects.filter(event=event, level=i))
    print max_questions
    width=max_questions*200 + len(answers)*11
    return width

def get_height(event):
    max_level=get_max_level(event)
    number=len(Answer.objects.filter(question__event=event))
    height=(max_level-1)*80 + 80 + (number)*7*(max_level-1)
    return height
 
def get_diff(event):
    questions=Question.objects.filter(event=event)
    return len(questions)*5  
